<?php $__env->startSection('title', 'Edit Lokasi'); ?>

<?php $__env->startSection('content'); ?>
  <section class="content">
    <div class="panel panel-default">
      <div class="panel-heading">	
        <h2>Edit Lokasi</h2>
      </div>
      <div class="panel-body">
        
          <form method="post" action="<?php echo e(url('lokasi/edit/'.$detail->id)); ?>">
            <?php echo csrf_field(); ?>
            
            

            <div class="form-group">
            <label>Nama Lokasi</label>
            <input class="form-control" name="nama_lokasi" value="<?php echo e($detail->nama_lokasi); ?>" required />
            </div>
           

            <div class="form-group">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" onclick="window.history.back();" class="btn btn-success">Kembali</button>
            </div>
          </form>
      </div>
    </div>
  </section>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\manajemen_aset_baru\resources\views/lokasi_edit.blade.php ENDPATH**/ ?>