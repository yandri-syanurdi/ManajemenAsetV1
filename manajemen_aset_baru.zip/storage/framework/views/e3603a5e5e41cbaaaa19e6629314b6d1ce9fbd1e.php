<?php $__env->startSection('title', 'Edit Kondisi Aset'); ?>

<?php $__env->startSection('content'); ?>
  <section class="content">
    <div class="panel panel-default">
      <div class="panel-heading">	
        <h2>Edit Data Kondisi Aset</h2>
        <h4><?php echo e($data_aset->kode_aset); ?> - <?php echo e($data_aset->nama_aset); ?></h4>
      </div>
      <div class="panel-body">
        
          <form method="post" action="<?php echo e(url('kondisi-aset/edit/'.$detail->id)); ?>">
            <?php echo csrf_field(); ?>
            
            
            <div class="form-group">
            <label>Kondisi</label>
            <select class="form-control" name="kondisi" required>
              <option selected disabled>-- Pilih Kondisi Aset --</option>
              <option value="Good">Good</option>
              <option value="Bad">Bad</option>
              <option value="Lost">Lost</option>
              <option value="Damaged">Damaged</option>
            </select>
            <script>
              document.getElementsByName("kondisi")[0].value = "<?php echo e($detail->kondisi); ?>";
            </script>
            </div>

            <div class="form-group">
            <label>Tanggal Kondisi</label>
              <input class="form-control" name="tanggal_kondisi" type="date" value="<?php echo e($tgl); ?>" required />
            </div>
            <div class="form-group">
            <label>Jam Kondisi</label>
              <input class="form-control" name="jam_kondisi" type="time" value="<?php echo e($jam); ?>" required />
            </div>
			
			<div class="form-group">
            <label>Deskripsi</label>
            <input class="form-control" name="deskripsi" value="<?php echo e($detail->deskripsi); ?>" required />
            </div>
			
			<div class="form-group">
			<label>Gambar</label>
            <input class="form-control" name="gambar" value="<?php echo e($detail->gambar); ?>" required />
            </div>

            <div class="form-group">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" onclick="window.history.back();" class="btn btn-success">Kembali</button>
            </div>
          </form>
      </div>
    </div>
  </section>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\manajemen_aset_baru\resources\views/kondisi_aset_edit.blade.php ENDPATH**/ ?>