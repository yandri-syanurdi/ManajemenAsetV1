<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>
  <section class="content">
    <div class="card">
      <div class="card-header">	
        <h4>Edit Data User</h4>
      </div>
      <div class="card-body">
        
          <form method="post" action="<?php echo e(url('users/edit/'.$detail->id)); ?>">
            <?php echo csrf_field(); ?>
            
            <div class="form-group">
            <label>Nama</label>
            <input class="form-control" name="name" value="<?php echo e($detail->name); ?>" required />
            </div>

            <div class="form-group">
            <label>Email</label>
            <input class="form-control" name="email" value="<?php echo e($detail->email); ?>" required />
            </div>

			<div class="form-group">
            <label>
              Password <br>
              <small>*Masukan password baru jika ingin mengganti password</small>
            </label>
            <input class="form-control" name="password" type="password" required />
            </div>

            <div class="form-group">
            <label>Jenis Kelamin</label>
            <select class="form-control" name="jenis_kelamin" required>
              <option value="Laki-Laki">Laki-Laki</option>
              <option value="Perempuan">Perempuan</option>
            </select>
            <script>
              document.getElementsByName("jenis_kelamin")[0].value = "<?php echo e($detail->jenis_kelamin); ?>";
            </script>
            </div>
      <div class="form-group">
            <label>Nohp</label>
            <input class="form-control" name="nohp" type="text" value="<?php echo e($detail->nohp); ?>" required />
            </div>

            <div class="form-group">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" onclick="window.history.back();" class="btn btn-success">Kembali</button>
            </div>
          </form>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\manajemen_aset_baru\resources\views/users_edit.blade.php ENDPATH**/ ?>