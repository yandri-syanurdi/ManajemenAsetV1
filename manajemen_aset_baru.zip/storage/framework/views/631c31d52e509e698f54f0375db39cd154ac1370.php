<?php $__env->startSection('title', 'Edit Kategori Aset'); ?>

<?php $__env->startSection('content'); ?>
  <section class="content">
    <div class="card">
      <div class="card-header">	
        <h4>Edit Data Kategori Aset</h4>
      </div>
      <div class="card-body">
        
          <form method="post" action="<?php echo e(url('kategori-aset/edit/'.$detail->id)); ?>">
            <?php echo csrf_field(); ?>
            
            <div class="form-group">
            <label>Kode Kategori Aset</label>
            <input class="form-control" name="kode_kategori" value="<?php echo e($detail->kode_kategori); ?>" required />
            </div>

            <div class="form-group">
            <label>Nama Kategori Aset</label>
            <input class="form-control" name="nama_kategori" value="<?php echo e($detail->nama_kategori); ?>" required />
            </div>
           

            <div class="form-group">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" onclick="window.history.back();" class="btn btn-success">Kembali</button>
            </div>
          </form>
      </div>
    </div>
  </section>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\manajemen_aset_baru\resources\views/kategori_aset_edit.blade.php ENDPATH**/ ?>